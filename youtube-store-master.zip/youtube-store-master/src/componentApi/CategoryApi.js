export const ApiCategories =[
    {
        title : 'Jeans',
        src : 'https://images.pexels.com/photos/1082529/pexels-photo-1082529.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    },
    {
        title: 'Jackets',
        src : 'https://images.pexels.com/photos/6770028/pexels-photo-6770028.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    },
    {
        title: 'Style Tee Shirts',
        src : 'https://images.pexels.com/photos/8346230/pexels-photo-8346230.jpeg?auto=compress&cs=tinysrgb&dpr=3&h=750&w=1260'
    }
]