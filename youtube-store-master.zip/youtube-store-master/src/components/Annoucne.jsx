import React from 'react';

const Annoucne = () => {
  return <div className='bg-[#8a4af3] font-bold text-white flex items-center justify-center'>
      Hurry up 50% off Sale!
  </div>;
};

export default Annoucne;
