![Flutter](https://user-images.githubusercontent.com/55942632/74084072-1d450f80-4a91-11ea-92bd-c3cb27468109.png)

# Design, Build and Deploy Your First Flutter 💙 Website!

🔥 [Subscribe](https://www.youtube.com/channel/UCsPdgUIoOBTBI1UmulW1pdw?sub_confirmation=1) for more

1. In this video you will learn how to build your first ever flutter website for beginner

If you want to host already build website check out the next video tutorial in which i will show how to 

2. Host Flutter website with Firebase : Not Uploaded Yet (Subscribe)
3. Host FLutter website with Codemagic : Not Uploaded Yet (Subscribe)

About Flutter Web :
Flutter web support is a code-compatible implementation of Flutter that is rendered using standards-based web technologies: HTML, CSS and JavaScript. With web support, you can compile existing Flutter code written in Dart into a client experience that can be embedded in the browser and deployed to any web server. You can use all the features of Flutter, and you don’t need a browser plug-in.

.
[🖥️ App Landing Page Made with Flutter Web](https://github.com/theindianappguy/applandingpage)

Say hi 👋 on [Linkedin](https://www.linkedin.com/in/lamsanskar/)
