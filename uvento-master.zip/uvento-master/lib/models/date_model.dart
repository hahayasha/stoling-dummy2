class DateModel{

  String weekDay;
  String date;

}