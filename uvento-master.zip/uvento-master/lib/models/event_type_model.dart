class EventTypeModel{

  String imgAssetPath;
  String eventType;
}