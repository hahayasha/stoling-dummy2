![true false quiz app made with flutter by theindianappguy](https://user-images.githubusercontent.com/55942632/81511470-62e6d200-9337-11ea-8bee-f0d3d5364c9a.png)

Fun Trivia game made wtih flutter taught on yotube.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
