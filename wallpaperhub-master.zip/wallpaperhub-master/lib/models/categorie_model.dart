class CategorieModel {
  String categorieName;
  String imgUrl;
}
