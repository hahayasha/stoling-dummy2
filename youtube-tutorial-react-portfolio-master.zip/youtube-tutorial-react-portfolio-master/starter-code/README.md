## React-portfolio website - Starter code

## Note

### To achieve the same result, you need to:

- Follow all the steps and instructions that will be given in the tutorial.
- Refer to the complete code if you come accross any error.
