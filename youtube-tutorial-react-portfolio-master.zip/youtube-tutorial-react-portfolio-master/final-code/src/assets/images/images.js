export { default as squidGame } from '../assets/images/squid-game.jpg'
export { default as gpt3 } from '../assets/images/gpt3.jpg'