package com.example.scooterapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
