# Scooter App

#### This Design is implemented in Flutter and the video is live [here](https://www.youtube.com/watch?v=g2cOyuAHep0)

#### Flutter App UI implementation inspired from a design on Dribbble

# The Design


![Alt text](/design.jpeg)
# The Flutter App
| ![Alt text](/Screenshot1.png) | ![Alt text](/Screenshot2.png) |
| ------------- | ------------- |

# Youtube Video
![Alt text](/thumbnail.png)
#### This Design is implemented in Flutter and the video is live [here](https://www.youtube.com/watch?v=g2cOyuAHep0)
